import 'package:flutter/material.dart';
import 'navigation.dart';
import 'package:carousel_slider/carousel_slider.dart';

void main() {
  runApp(MyApp());
}

final List<Map<String, String>> imgList = [

  {
    'url' : 'assets/f1.jpg',
    'description' : 'Korean Food: where tradition meets innovation.',
  },
  {
    'url' : 'assets/h1.jpg',
    'description' : 'A meal that brings people together is always the best meal.',
  },
  {
    'url' : 'assets/h2.jpg',
    'description' : 'Flavors that warm the heart and comfort the soul',
  },

];


class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
            appBar: AppBar(title: Text ('',
              style: TextStyle(
                fontSize: 28,
                color: Colors.red,
              ),),
              leading: Builder(builder: (context) => IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () => Scaffold.of(context).openDrawer(),
              ),
              ),
            ),

            drawer: Drawer(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  DrawerHeader(
                    decoration: const BoxDecoration(
                      color: Colors.grey,
                    ),
                    child: Image.network(
                      'assets/head.jpg',
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) => Text(
                        'missing logo',
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 24,
                        ),
                      ),

                    ),
                  ),

                  ListTile(
                    leading: const Icon(Icons.arrow_forward),
                    title: const Text('HOME'),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.arrow_forward),
                    title: const Text('TTEOKBOKKI RECIPE'),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.arrow_forward),
                    title: const Text('KIMBAP RECIPE'),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            ),


            body: Center(
              child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(padding: const EdgeInsets.fromLTRB(16.5, 16.5, 16.5, 8.10),
                  child: Text(
                    'KOREAN FOOD RECIPE',
                    style: TextStyle(
                      fontSize: 40,
                      fontWeight: FontWeight.bold,
                      color: Colors.red,
                    ),
                  ),
                ),

                Padding(padding: const EdgeInsets.symmetric(vertical: 20.0),
                  child: CarouselSlider(
                      options: CarouselOptions(
                        height: 300.0,
                        autoPlay: true,
                        enlargeCenterPage: true,
                      ),
                      items: imgList.map((item) {
                        return Container(
                          margin: const EdgeInsets.symmetric(horizontal: 5.0),
                          child: Column(
                            children: [
                              Expanded(
                                child: Image.network(
                                  item['url']!,
                                  fit: BoxFit.cover,
                                  width: double.infinity,
                                  errorBuilder: (context, error, stackTracer) => Icon(Icons.error),
                                ),
                              ),

                              Container(
                                color: Colors.red.withOpacity(0.9),
                                padding: const EdgeInsets.all(8.0),
                                margin: const EdgeInsets.only(top: 8.0),
                                child: Text(
                                  item['description']!,
                                  style: const TextStyle(
                                    fontSize: 20,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  textAlign: TextAlign.center,
                                  maxLines: 3,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList()
                  ),
                ),

                Padding(padding: EdgeInsets.symmetric(horizontal: 16.8),
                  child: Text('',
                    style: TextStyle(fontSize: 20,
                        color: Colors.red,
                        fontWeight: FontWeight.bold),
                  ),),

            ],
          )
        )
      )
    );
  }
}