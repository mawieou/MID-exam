import 'package:flutter/material.dart';
import 'pages/home_page.dart';
import 'pages/kimbap.dart';
import 'pages/tteokbokki.dart';

class MainNavigationPage extends StatefulWidget {
  @override
  _MainNavigationPageState createState() => _MainNavigationPageState();
}

class _MainNavigationPageState extends State {
  int _selectedIndex = 2;
  PageController _pageController = PageController(initialPage: 2);

  @override
  Widget build(BuildContext context) {
      return Scaffold(
        body: PageView(
          controller: _pageController,


          children: [
            Kimbap(),
            Tteokbokki(),
            HomePage(),
          ],
          onPageChanged: (index) {
            setState(() {
              _selectedIndex = index;
            });
          },
        ),
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
            currentIndex: _selectedIndex,
            onTap: _onTabTapped,

            selectedItemColor: Colors.blue,
            unselectedItemColor: Colors.blueGrey,
            elevation: 8.0,
            backgroundColor: Colors.white,

            items: [
              BottomNavigationBarItem(icon: Icon(Icons.rice_bowl_outlined), label: 'Tteokbokki Recipe'),
              BottomNavigationBarItem(icon: Icon(Icons.rice_bowl_outlined), label: 'Kimbap Recipe'),
              BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
            ],
        ),
      );

  }

  void _onTabTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    _pageController.animateToPage(index, duration: Duration(milliseconds: 300), curve: Curves.bounceInOut,
    );
  }

  @override
  void dispose(){
    _pageController.dispose();
      super.dispose();
  }

}