import 'package:flutter/material.dart';


class HomePage extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Korean Foods'),
        backgroundColor: Colors.blueGrey,
        centerTitle: true,
      ),
      body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.network('assets/korean.jpg',
                width: 400,
                height: 300,
              ),
              const SizedBox(height: 25),
              const Text(
                  'KOREAN FOOD RECIPE',
                  style: TextStyle(fontSize: 25),
              ),
            ],
          )
      ),
    );
  }
}