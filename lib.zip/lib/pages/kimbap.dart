import 'package:flutter/material.dart';

class Kimbap extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text(''),
        backgroundColor: Colors.blueGrey,
        centerTitle: true,
      ),
      body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.network('assets/kimbap.jpg',
                width: 100,
                height: 100,
              ),
              const SizedBox(height: 25),
              const Text(
                  'KIMBAP RECIPE',
                  style: TextStyle(fontSize: 25)
              ),
              const Text(
                  'MISSION',
                  style: TextStyle(fontSize: 25)
              ),
            ],
          )
      ),
    );
  }
}